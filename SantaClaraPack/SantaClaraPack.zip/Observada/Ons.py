import pandas as pd
import openpyxl as pyxl

class Vazao(object):

    def __init__(self):
        pass

    def get_serie_historica(self, path):

        

        pass